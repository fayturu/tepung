# TepungLootAll 1.5.0 source

This source revision changes chat claiming to Bukkit's `AsyncPlayerChatEvent` compatibility event and always delivers rewards on the main server thread. It also splits rewards into legal stack sizes, dropping overflow at the player's location.

## Commands
- `/lootall <item> <amount>`
- `/lootall random <amount>`
- `/lootall stop`
- `/lootall reload`

Players claim by sending exactly `W` or `w` in chat, with no other text. One claim per player per event.

## Animation
The title animates a rotating spinner around `LOOTALL` for about 5 seconds. The subtitle says `TYPE W TO CLAIM!`.

## Important icon limitation
Vanilla Minecraft title text cannot display a live item-render icon. This version uses animated glyph symbols around the title. To show the actual reward item icon beside the title, a matching client resource pack with custom font glyphs and item textures must also be created and installed by players.

## Build
Requires JDK 25 and Gradle. Run `gradle build`; output is in `build/libs/`.
