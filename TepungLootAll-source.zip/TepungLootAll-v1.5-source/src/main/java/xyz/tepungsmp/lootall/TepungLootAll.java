package xyz.tepungsmp.lootall;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;

public final class TepungLootAll extends JavaPlugin implements Listener {
    private volatile List<Material> randomLoot = List.of();
    private volatile LootEvent currentEvent;
    private final Set<UUID> claimed = ConcurrentHashMap.newKeySet();
    private BukkitTask animationTask;
    private long nextEventId = 0L;

    private static final String[] SPIN = {
            "◜", "◝", "◞", "◟", "◜", "◝", "◞", "◟"
    };

    private static final class LootEvent {
        final long id;
        final Material material;
        final int amount;

        LootEvent(long id, Material material, int amount) {
            this.id = id;
            this.material = material;
            this.amount = amount;
        }
    }

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadLootConfig();
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("TepungLootAll enabled. Loaded " + randomLoot.size() + " configured loot items.");
    }

    @Override
    public void onDisable() {
        stopAnimation();
        currentEvent = null;
        claimed.clear();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!command.getName().equalsIgnoreCase("lootall")) return false;

        if (!sender.hasPermission("tepunglootall.admin")) {
            sender.sendMessage(ChatColor.RED + "You don't have permission.");
            return true;
        }

        if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {
            reloadConfig();
            loadLootConfig();
            sender.sendMessage(ChatColor.GREEN + "LootAll config reloaded. Loaded " + randomLoot.size() + " items.");
            return true;
        }

        if (args.length == 1 && args[0].equalsIgnoreCase("stop")) {
            if (currentEvent == null) {
                sender.sendMessage(ChatColor.RED + "No LootAll event is running.");
                return true;
            }
            currentEvent = null;
            claimed.clear();
            stopAnimation();
            broadcast(ChatColor.RED + "The LootAll event has been stopped.");
            return true;
        }

        if (args.length != 2) {
            sender.sendMessage(ChatColor.YELLOW + "Usage: /lootall <item|random> <amount> | /lootall stop | /lootall reload");
            sender.sendMessage(ChatColor.GRAY + "Example: /lootall golden_apple 5");
            return true;
        }

        Material selected;
        if (args[0].equalsIgnoreCase("random")) {
            List<Material> choices = randomLoot;
            if (choices.isEmpty()) {
                sender.sendMessage(ChatColor.RED + "No valid items in config.yml loot-items list.");
                return true;
            }
            selected = choices.get(ThreadLocalRandom.current().nextInt(choices.size()));
        } else {
            selected = Material.matchMaterial(args[0]);
        }

        if (selected == null || !selected.isItem() || selected.isAir()) {
            sender.sendMessage(ChatColor.RED + "Invalid item. Example: golden_apple");
            return true;
        }

        int requestedAmount;
        try {
            requestedAmount = Integer.parseInt(args[1]);
        } catch (NumberFormatException ex) {
            sender.sendMessage(ChatColor.RED + "Amount must be a whole number.");
            return true;
        }

        if (requestedAmount < 1 || requestedAmount > 2304) {
            sender.sendMessage(ChatColor.RED + "Amount must be between 1 and 2304.");
            return true;
        }

        claimed.clear();
        currentEvent = new LootEvent(++nextEventId, selected, requestedAmount);
        startAnimation();
        broadcast(ChatColor.GOLD + "" + ChatColor.BOLD + "LOOTALL "
                + ChatColor.YELLOW + " - Type " + ChatColor.WHITE + "W"
                + ChatColor.YELLOW + " in chat to claim!");
        sender.sendMessage(ChatColor.GREEN + "LootAll started: " + requestedAmount + "x "
                + selected.name().toLowerCase(Locale.ROOT) + ".");
        return true;
    }

    private void loadLootConfig() {
        List<Material> loaded = new ArrayList<>();
        for (String raw : getConfig().getStringList("loot-items")) {
            Material material = Material.matchMaterial(raw);
            if (material != null && material.isItem() && !material.isAir() && !loaded.contains(material)) {
                loaded.add(material);
            } else {
                getLogger().warning("Ignoring invalid loot item in config.yml: " + raw);
            }
        }
        randomLoot = List.copyOf(loaded);
    }

    /*
     * Legacy Bukkit chat event is deliberately used here for compatibility with
     * plugins which still route player chat through AsyncPlayerChatEvent.
     * Claim delivery is always moved onto the main server thread.
     */
    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onPlayerChat(AsyncPlayerChatEvent event) {
        if (!event.getMessage().trim().equalsIgnoreCase("w")) return;

        LootEvent snapshot = currentEvent;
        if (snapshot == null) return;

        event.setCancelled(true);
        Player player = event.getPlayer();
        UUID playerId = player.getUniqueId();

        if (!claimed.add(playerId)) {
            Bukkit.getScheduler().runTask(this,
                    () -> player.sendMessage(ChatColor.RED + "You have already claimed this LootAll."));
            return;
        }

        Bukkit.getScheduler().runTask(this, () -> {
            LootEvent now = currentEvent;
            if (now == null || now.id != snapshot.id) {
                claimed.remove(playerId);
                player.sendMessage(ChatColor.RED + "This LootAll event has ended.");
                return;
            }

            int remaining = snapshot.amount;
            int maxStack = Math.max(1, snapshot.material.getMaxStackSize());

            while (remaining > 0) {
                int stackAmount = Math.min(remaining, maxStack);
                ItemStack stack = new ItemStack(snapshot.material, stackAmount);
                var leftovers = player.getInventory().addItem(stack);
                leftovers.values().forEach(item ->
                        player.getWorld().dropItemNaturally(player.getLocation(), item));
                remaining -= stackAmount;
            }

            player.sendMessage(ChatColor.GREEN + "CLAIMED! "
                    + ChatColor.GOLD + snapshot.amount + "x "
                    + snapshot.material.name().toLowerCase(Locale.ROOT).replace('_', ' '));
            player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.25f);
        });
    }

    private void startAnimation() {
        stopAnimation();
        animationTask = Bukkit.getScheduler().runTaskTimer(this, new Runnable() {
            private int frame = 0;
            private int ticks = 0;

            @Override
            public void run() {
                LootEvent event = currentEvent;
                if (event == null || ticks++ >= 100) {
                    stopAnimation();
                    return;
                }

                String spinner = SPIN[frame++ % SPIN.length];
                String title = ChatColor.GOLD + "" + ChatColor.BOLD
                        + spinner + "  LOOTALL  " + spinner;
                String subtitle = ChatColor.YELLOW + "" + ChatColor.BOLD + "TYPE W TO CLAIM!";
                for (Player player : Bukkit.getOnlinePlayers()) {
                    player.sendTitle(title, subtitle, 0, 8, 0);
                }
            }
        }, 0L, 4L);
    }

    private void stopAnimation() {
        if (animationTask != null) {
            animationTask.cancel();
            animationTask = null;
        }
    }

    private void broadcast(String message) {
        for (Player player : Bukkit.getOnlinePlayers()) {
            player.sendMessage(message);
        }
        getLogger().info(ChatColor.stripColor(message));
    }
}
